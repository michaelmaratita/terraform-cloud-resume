import json
import boto3

client = boto3.client('sns')

def lambda_handler(event, context):
    sendMail(event)
    return {
        'statusCode': 200
    }


def sendMail(event):
    topic_arn = 'arn:aws:sns:us-west-1:652752229463:mailme'
    body = f'Message from {event["name"]}:\n\n{event["body"]}\n\nName: ' + \
    f'{event["name"]}\nPhone: {event["phone"]}\nEmail: {event["email"]}' 

    client.publish(
        TopicArn = topic_arn,
        Message = body,
        Subject = event["subject"]
        )